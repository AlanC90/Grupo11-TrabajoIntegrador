from src.inicio import ejecutar
if __name__=="main":}
	ejecutar()
